
CREATE DATABASE LOAN_DW
GO

USE LOAN_DW
GO 

-- Create the calendar dimension table
CREATE TABLE Calendar_Dimension (
  CalendarKey INT NOT NULL IDENTITY,
  FullDate DATE NOT NULL,
  day_of_week VARCHAR(20) NOT NULL,
  day_type VARCHAR(20) NOT NULL,
  day_of_month INT NOT NULL,
  month_of_year VARCHAR(20) NOT NULL,
  quarter VARCHAR(20) NOT NULL,
  year INT NOT NULL,
  PRIMARY KEY (CalendarKey)
);


GO
CREATE TABLE Account_Dimension (
  AccountKey INT NOT NULL IDENTITY,
  account_id INT NOT NULL,
  account_frequency VARCHAR(20),
  account_date DATE, 
  account_district_name VARCHAR(20),
  account_order_amountDebited NUMERIC(10,2),
  PRIMARY KEY (AccountKey)
);
GO

CREATE TABLE Card_Dimension (
  CardKey INT NOT NULL IDENTITY,
  card_id INT NOT NULL, 
  card_Type VARCHAR(10),
  card_Issued DATE,
  PRIMARY KEY (CardKey)
);
GO
CREATE TABLE Client_Dimension (
  ClientKey INT NOT NULL IDENTITY,
  client_id INT NOT NULL,
  client_birthNumber DATE NOT NULL,
  client_disposition_type VARCHAR(10),
  PRIMARY KEY (ClientKey)
);
GO
CREATE TABLE Transaction_Dimension 
(
  TransactionKey INT NOT NULL IDENTITY,
  transaction_id INT NOT NULL,
  transaction_date DATE,
  transaction_type VARCHAR(20),      
  transaction_operation VARCHAR(50),  
  transaction_amount NUMERIC(10,2),  
  balance_after_transaction NUMERIC(10,2),
  transaction_k_symbol VARCHAR(50),
  PRIMARY KEY (TransactionKey)
);
GO
-- Create the loan fact table
CREATE TABLE Loan_Fact
(
  AccountKey INT NOT NULL,
  CalendarKey INT NOT NULL,
  CardKey INT NOT NULL,
  ClientKey INT NOT NULL,
  TransactionKey INT NOT NULL,
  LoanDate DATE,
  LoanAmount NUMERIC(10,2),
  LoanDuration INT,
  LoanPayments NUMERIC(10,2),
  LoanStatus VARCHAR(100),
  Order_K_Symbol VARCHAR(50),
  PRIMARY KEY (AccountKey,CalendarKey,CardKey,ClientKey,TransactionKey),
  FOREIGN KEY (AccountKey) REFERENCES Account_Dimension(AccountKey),
  FOREIGN KEY (CalendarKey) REFERENCES Calendar_Dimension(CalendarKey),
  FOREIGN KEY (CardKey) REFERENCES Card_Dimension(CardKey),
  FOREIGN KEY (ClientKey) REFERENCES Client_Dimension(ClientKey),
  FOREIGN KEY (TransactionKey) REFERENCES Transaction_Dimension(TransactionKey)
);
GO




