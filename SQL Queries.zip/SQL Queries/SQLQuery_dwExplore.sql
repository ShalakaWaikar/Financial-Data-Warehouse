use [Banking]
--Account Table
select count(*) from [Banking].[dbo].[Account]
--4500
select count(distinct [account_id]) from [Banking].[dbo].[Account]
--4500
select count(distinct [frequency]) from [Banking].[dbo].[Account]
--3
select count(distinct date) from [Banking].[dbo].[Account]
--1535


--Loan Table
select count(*) from [Loan].[dbo].[Loan]
--682
select count(distinct [loan_id]) from [Loan].[dbo].[Loan]
--682
select l.[loan_id], sum(l.[amount]) from [Loan].[dbo].[Loan] l
group by l.[loan_id]
order by l.[loan_id]
--
--count of status and date of each loan
select l.[loan_id], count(l.status) as "CountStatus", count(l.date) as "CountTo_date" from [Loan].[dbo].[Loan] l
group by l.[loan_id]
order by l.[loan_id]
--
--getting amount, date of each loan
select l.[loan_id], l.[amount], l.[date] from [Loan].[dbo].[Loan] l
order by l.[loan_id]
--
--getting all details with date(recent) each loan
select * from [Loan].[dbo].[Loan] l
order by l.[loan_id], l.[date] desc
--
select l.date from [Loan].[dbo].[Loan] l
where l.[loan_id] = 4959
--
--loan and its max date
select l.[loan_id], max(l.[date]) as Maxdate from [Loan].[dbo].[Loan] l
group by l.[loan_id]
order by l.[loan_id]

--TABLE Account_Dimension
--checking for repeating [account_frequency]
use LOAN_DW

SELECT a.[account_frequency], COUNT(*)
FROM [LOAN_DW].[dbo].[Account_Dimension] a
GROUP BY a.[account_frequency]
HAVING COUNT(*) > 1

--TABLE FactTable
select count(*) FROM [LOAN_DW].[dbo].[Loan_Fact]
--
SELECT TOP (1000) [AccountKey]
      ,[account_id]
      ,[account_frequency]
      ,[account_date]
      ,[account_district_name]
      ,[account_order_amountDebited]
  FROM [LOAN_DW].[dbo].[Account_Dimension]
