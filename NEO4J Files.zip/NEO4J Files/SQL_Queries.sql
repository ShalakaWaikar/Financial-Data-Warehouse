Use FInanceData
go

--Query 1
Select d.district_name
, d.region
from District d
where d.district_name like 'P%'
and d.region = 'south Bohemia'
order by d.district_name asc
;

--Query 2
select d.region as region
, count(a.account_id) as count_of_account_holders
from Account a
inner join District d on a.district_id = d.district_id 
group by d.region
order by count(a.account_id) desc
;


--Query 3
Select min(duration) as min_duration, max(duration) as max_duration
from Loan l;
 
--Query 4
select t.account_id
, sum(t.amount) as total_credits
from Transaction_Details t
where t.type = 'Credit'
group by t.account_id 
order by t.account_id asc
;

--Query 5
select year(l.loan_granted_date)
, count(l.account_id) as count_of_account_holders
from Loan l 
where l.status = 'Finished contract, loan not paid'
group by year(l.loan_granted_date)
;

--Query 6
Select t.account_id
, t.transaction_date
, balance
from Transaction_Details t 
where t.account_id = '11333'
and t.transaction_date in (select max(transaction_date) from Transaction_Details otd where otd.account_id = t.account_id group by otd.account_id)
;


--Query 7
select d.region as region
, l.status
, count(*) AS count_account_id
from Account a
inner join District d on a.district_id = d.district_id 
inner join Loan l on l.account_id = a.account_id
group by d.region, l.status 
order by d.region, l.status asc
;